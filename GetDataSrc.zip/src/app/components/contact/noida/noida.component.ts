import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-noida',
  templateUrl: './noida.component.html',
  styleUrls: ['./noida.component.css']
})
export class NoidaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
