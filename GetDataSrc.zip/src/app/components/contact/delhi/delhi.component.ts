import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delhi',
  templateUrl: './delhi.component.html',
  styleUrls: ['./delhi.component.css']
})
export class DelhiComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
