import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  title = 'Neosoft Tecnologies';
  courses:any=[];
  imgUrl="https://picsum.photos/200/300";
  fname="Abhi";
  empData=[
    {"id":1,"name":"A","age":23,"city":"noida"},
    {"id":2,"name":"B","age":33,"city":"delhi"},
    {"id":3,"name":"C","age":43,"city":"noida"},
    {"id":4,"name":"D","age":53,"city":"delhi"},
    {"id":5,"name":"E","age":63,"city":"noida"},
  ]
  abc(){
    alert(`Hello ${this.fname}`)
    this.courses=["php",".net","java","python"];
    if(this.imgUrl.length<60){
      this.imgUrl="https://media.istockphoto.com/photos/beautiful-luxury-home-exterior-at-twilight-picture-id1026205392?k=20&m=1026205392&s=612x612&w=0&h=lYFMV5cOuQQpddmwsE5QLBCyhgWQ1OI46i_dalro9OE="
      }
    else {
      this.imgUrl="https://picsum.photos/200/300";
    }
    
  }
}
