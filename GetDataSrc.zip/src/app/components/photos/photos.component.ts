import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import * as $ from 'jquery';

@Component({
  selector: 'app-photos',
  templateUrl: './photos.component.html',
  styleUrls: ['./photos.component.css']
})
export class PhotosComponent implements OnInit {
  URL:any="https://jsonplaceholder.typicode.com/photos";
  photosData:any;
 constructor(private http:HttpClient) { }

 ngOnInit(): void {
      this.http.get(this.URL)
      .subscribe(res=>{
        if(res){
          $('.spinner-border').hide();
        }
       this.photosData=res;
      })
 }
}
